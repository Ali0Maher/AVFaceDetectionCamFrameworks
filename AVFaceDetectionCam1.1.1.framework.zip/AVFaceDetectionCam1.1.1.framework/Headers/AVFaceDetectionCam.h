//
//  AVFaceDetectionCam.h
//  AVFaceDetectionCam
//
//  Created by Ali on 8/26/21.
//

#import <Foundation/Foundation.h>

//! Project version number for AVFaceDetectionCam.
FOUNDATION_EXPORT double AVFaceDetectionCamVersionNumber;

//! Project version string for AVFaceDetectionCam.
FOUNDATION_EXPORT const unsigned char AVFaceDetectionCamVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AVFaceDetectionCam/PublicHeader.h>


